<?php
require_once __DIR__ . '/../config/database.php';

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function generateOrderId() {
    return 'ORD-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function getAuthUser() {
    // Get token from header or request
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? $_GET['token'] ?? $_POST['token'] ?? null;
    
    if (!$token) {
        // Try to get from cookie
        $token = $_COOKIE['auth_token'] ?? null;
    }
    
    if (!$token) {
        return null;
    }
    
    // Decode token (simple base64 for now, in production use JWT)
    try {
        $decoded = json_decode(base64_decode($token), true);
        if (isset($decoded['user_id'])) {
            $database = new Database();
            $db = $database->getConnection();
            
            $query = "SELECT id, name, username, email, role, phone, address FROM users WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $decoded['user_id']);
            $stmt->execute();
            return $stmt->fetch();
        }
    } catch (Exception $e) {
        return null;
    }
    
    return null;
}

function requireAuth($requiredRole = null) {
    $user = getAuthUser();
    
    if (!$user) {
        sendError('Authentication required', 401);
    }
    
    if ($requiredRole && $user['role'] !== $requiredRole) {
        sendError('Insufficient permissions', 403);
    }
    
    return $user;
}

function generateToken($userId, $role) {
    return base64_encode(json_encode(['user_id' => $userId, 'role' => $role]));
}
?>

