<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$userId = $_GET['user_id'] ?? null;

if (!$userId) {
    sendError('User ID is required');
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT id, name, username, email, phone, address, role, created_at FROM users WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $userId);
$stmt->execute();

$user = $stmt->fetch();

if (!$user) {
    sendError('User not found', 404);
}

// Get user's orders count
$ordersQuery = "SELECT COUNT(*) as order_count FROM orders WHERE user_id = :user_id";
$ordersStmt = $db->prepare($ordersQuery);
$ordersStmt->bindParam(':user_id', $userId);
$ordersStmt->execute();
$orderData = $ordersStmt->fetch();
$user['order_count'] = $orderData['order_count'] ?? 0;

sendResponse(true, 'User profile retrieved successfully', $user);
?>

