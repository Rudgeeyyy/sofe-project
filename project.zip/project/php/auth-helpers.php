<?php
require_once __DIR__ . '/database.php';

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function generateOrderId() {
    return 'ORD-' . str_pad(time() % 10000, 4, '0', STR_PAD_LEFT);
}

function verifyToken($token) {
    // Implement JWT token verification here
    // For now, return user ID from token
    return null;
}
?>

