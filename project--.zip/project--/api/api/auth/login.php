<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/response.php';
require_once __DIR__ . '/../../utils/auth-helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email']) || !isset($data['password'])) {
    sendError('Email and password are required');
}

$email = trim($data['email']);
$password = $data['password'];
$role = $data['role'] ?? null; // Optional role filter for admin/cashier login

$database = new Database();
$db = $database->getConnection();

$query = "SELECT id, name, username, email, password, role, phone, address FROM users WHERE (email = :email OR username = :email)";
if ($role) {
    $query .= " AND role = :role";
}
$stmt = $db->prepare($query);
$stmt->bindParam(':email', $email);
if ($role) {
    $stmt->bindParam(':role', $role);
}
$stmt->execute();

$user = $stmt->fetch();

if (!$user) {
    sendError('Invalid email or password', 401);
}

if (!verifyPassword($password, $user['password'])) {
    sendError('Invalid email or password', 401);
}

// Remove password from response
unset($user['password']);

$token = generateToken($user['id'], $user['role']);

sendResponse(true, 'Login successful', [
    'user' => $user,
    'token' => $token
]);
?>

