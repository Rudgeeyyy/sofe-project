-- Database Setup for Jessie Cane Juice Bar
-- Execute this file in phpMyAdmin or MySQL command line

-- Step 1: Create Database
CREATE DATABASE IF NOT EXISTS jessie_cane_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jessie_cane_db;

-- Step 2: Create Tables

-- Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role ENUM('admin', 'cashier', 'customer') DEFAULT 'customer',
    google_id VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products Table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    image VARCHAR(500),
    price_regular DECIMAL(10, 2) NOT NULL,
    price_tall DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Orders Table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_username VARCHAR(100) DEFAULT '',
    customer_email VARCHAR(255),
    customer_phone VARCHAR(20),
    customer_notes TEXT,
    branch VARCHAR(100) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    tax DECIMAL(10, 2) DEFAULT 0,
    total DECIMAL(10, 2) NOT NULL,
    payment_method ENUM('GCash', 'Cash', 'Other') DEFAULT 'GCash',
    payment_status ENUM('Pending', 'Paid', 'Failed', 'Refunded') DEFAULT 'Pending',
    order_status ENUM('Pending', 'Approved', 'Processing', 'Ready', 'Out for Delivery', 'Completed', 'Cancelled') DEFAULT 'Pending',
    order_type ENUM('Digital', 'Walk-in') DEFAULT 'Digital',
    is_guest TINYINT(1) DEFAULT 0,
    timestamp BIGINT,
    order_date VARCHAR(50),
    order_time VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Order Items Table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    size VARCHAR(50) NOT NULL,
    special VARCHAR(100),
    notes TEXT,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Payments Table (for Xendit GCash transactions)
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    xendit_id VARCHAR(255) UNIQUE,
    xendit_reference VARCHAR(255),
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('Pending', 'Paid', 'Failed', 'Expired', 'Cancelled') DEFAULT 'Pending',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Event Inquiries Table
CREATE TABLE event_inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    event_type VARCHAR(100),
    event_date DATE,
    guest_count INT,
    location VARCHAR(255),
    message TEXT,
    status ENUM('New', 'Contacted', 'Confirmed', 'Cancelled') DEFAULT 'New',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Step 3: Insert Default Data

-- Insert Default Admin User
-- Password hash for 'admin123' using PHP password_hash()
INSERT INTO users (name, username, email, password, role) 
VALUES ('Main Admin', 'admin', 'admin@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert Sample Products
INSERT INTO products (name, description, image, price_regular, price_tall) VALUES
('Pure Sugarcane', 'Freshly pressed sugarcane juice in its purest form — naturally sweet, refreshing, and energizing with no added sugar or preservatives.', 'pure-sugarcane.png', 79.00, 109.00),
('Calamansi Cane', 'A zesty twist on classic sugarcane juice, blended with the tangy freshness of calamansi for a perfectly balanced sweet and citrusy drink.', 'calamansi-cane.png', 89.00, 119.00),
('Lemon Cane', 'Freshly squeezed lemon combined with pure sugarcane juice, creating a crisp and revitalizing drink that awakens your senses.', 'lemon-cane.png', 89.00, 119.00),
('Yakult Cane', 'A delightful mix of sugarcane juice and Yakult — smooth, creamy, and packed with probiotics for a unique sweet-tangy flavor.', 'yakult-cane.png', 89.00, 119.00),
('Calamansi Yakult Cane', 'A refreshing blend of calamansi, Yakult, and sugarcane juice — the perfect harmony of sweet, sour, and creamy goodness.', 'calamansi-yakult-cane.png', 99.00, 129.00),
('Lemon Yakult Cane', 'Experience a fusion of lemon''s zesty tang with Yakult''s smooth creaminess, all complemented by naturally sweet sugarcane.', 'lemon-yakult-cane.png', 99.00, 129.00),
('Lychee Cane', 'A fragrant and fruity treat made with the exotic sweetness of lychee and the crisp freshness of sugarcane juice.', 'lychee-cane.png', 99.00, 129.00),
('Orange Cane', 'Fresh orange juice blended with pure sugarcane extract for a bright, citrusy burst of sunshine in every sip.', 'orange-cane.png', 109.00, 139.00),
('Passion Fruit Cane', 'A tropical blend of tangy passion fruit and naturally sweet sugarcane — vibrant, juicy, and irresistibly refreshing.', 'passion-fruit-cane.png', 109.00, 139.00),
('Watermelon Cane', 'A hydrating fusion of freshly pressed watermelon and sugarcane juice, offering a light, cooling sweetness that''s perfect for hot days.', 'watermelon-cane.png', 109.00, 139.00),
('Dragon Fruit Cane', 'A vibrant blend of dragon fruit and pure sugarcane juice — visually stunning, naturally sweet, and loaded with antioxidants.', 'dragon-fruit-cane.png', 119.00, 149.00),
('Strawberry Yogurt Cane', 'Creamy strawberry yogurt meets sweet sugarcane for a smooth, fruity, and indulgent drink that''s both refreshing and satisfying.', 'strawberry-yogurt-cane.png', 119.00, 149.00);

