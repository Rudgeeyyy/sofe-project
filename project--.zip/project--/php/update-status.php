<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id']) || !isset($data['order_status'])) {
    sendError('Order ID and order_status are required');
}

$id = $data['id'];
$orderStatus = $data['order_status'];
$paymentStatus = $data['payment_status'] ?? null;

$database = new Database();
$db = $database->getConnection();

// Validate order status
$validStatuses = ['Pending', 'Approved', 'Processing', 'Ready', 'Out for Delivery', 'Completed', 'Cancelled'];
if (!in_array($orderStatus, $validStatuses)) {
    sendError('Invalid order status');
}

// Check if order exists
$query = "SELECT * FROM orders WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$order = $stmt->fetch();

if (!$order) {
    sendError('Order not found', 404);
}

// Update order status
if ($paymentStatus !== null) {
    $validPaymentStatuses = ['Pending', 'Paid', 'Failed', 'Refunded'];
    if (!in_array($paymentStatus, $validPaymentStatuses)) {
        sendError('Invalid payment status');
    }
    
    $query = "UPDATE orders SET order_status = :order_status, payment_status = :payment_status WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_status', $orderStatus);
    $stmt->bindParam(':payment_status', $paymentStatus);
    $stmt->bindParam(':id', $id);
} else {
    $query = "UPDATE orders SET order_status = :order_status WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_status', $orderStatus);
    $stmt->bindParam(':id', $id);
}

if ($stmt->execute()) {
    // Get updated order
    $query = "SELECT * FROM orders WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $order = $stmt->fetch();
    
    // Get order items
    $itemsQuery = "SELECT * FROM order_items WHERE order_id = :order_id";
    $itemsStmt = $db->prepare($itemsQuery);
    $itemsStmt->bindParam(':order_id', $order['id']);
    $itemsStmt->execute();
    $order['items'] = $itemsStmt->fetchAll();
    
    sendResponse(true, 'Order status updated successfully', $order);
} else {
    sendError('Failed to update order status');
}
?>

