// API Configuration for Frontend
// This file provides the base API URL for all frontend JavaScript files

const API_BASE_URL = 'http://localhost:8080/project/api/api';

// Make it globally available
if (typeof window !== 'undefined') {
    window.API_BASE_URL = API_BASE_URL;
}

