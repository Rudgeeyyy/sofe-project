<?php
// scripts/seed_cashiers.php
// Run this from project root with PHP CLI or open in browser under your local server.
// It uses api/config/database.php to connect and will insert two cashier users
// if they do not already exist. Passwords are hashed using PHP password_hash().

require_once __DIR__ . '/../api/config/database.php';

$db = new Database();
$conn = $db->getConnection();

$users = [
    [
        'name' => 'Cashier SJDM',
        'username' => 'cashier_sjdm',
        'email' => 'cashier.sjdm@jessiecane.com',
        'password' => 'cashier123',
        'role' => 'cashier'
    ],
    [
        'name' => 'Cashier Fairview',
        'username' => 'cashier_fairview',
        'email' => 'cashier.fairview@jessiecane.com',
        'password' => 'cashier123',
        'role' => 'cashier'
    ]
];

foreach ($users as $u) {
    // Check for existing user by email or username
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email OR username = :username LIMIT 1");
    $stmt->execute([':email' => $u['email'], ':username' => $u['username']]);
    $exists = $stmt->fetch();

    if ($exists) {
        echo "Skipping (already exists): {$u['email']} or username {$u['username']}\n";
        continue;
    }

    $hash = password_hash($u['password'], PASSWORD_DEFAULT);
    $insert = $conn->prepare("INSERT INTO users (name, username, email, password, role) VALUES (:name, :username, :email, :password, :role)");
    $insert->execute([
        ':name' => $u['name'],
        ':username' => $u['username'],
        ':email' => $u['email'],
        ':password' => $hash,
        ':role' => $u['role']
    ]);

    echo "Inserted user: {$u['email']} (username: {$u['username']})\n";
}

echo "Done.\n";

?>