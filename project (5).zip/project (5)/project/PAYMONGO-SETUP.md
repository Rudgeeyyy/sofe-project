# PayMongo Integration Setup Guide

This guide will help you set up PayMongo payment gateway for online payments in your Jessie Cane system.

## Step 1: Create PayMongo Account

1. Go to [https://paymongo.com](https://paymongo.com)
2. Sign up for an account
3. Complete the verification process

## Step 2: Get Your API Keys

1. Log in to [PayMongo Dashboard](https://dashboard.paymongo.com)
2. Go to **Settings** → **API Keys**
3. You'll see two types of keys:
   - **Public Key** (starts with `pk_test_` for testing or `pk_live_` for production)
   - **Secret Key** (starts with `sk_test_` for testing or `sk_live_` for production)

### For Testing:
- Use keys that start with `pk_test_` and `sk_test_`
- Test payments won't charge real money

### For Production:
- Use keys that start with `pk_live_` and `sk_live_`
- These will process real payments

## Step 3: Configure Webhook

1. In PayMongo Dashboard, go to **Settings** → **Webhooks**
2. Click **Create Webhook**
3. Set the webhook URL to:
   ```
   http://your-domain.com/project/php/paymongo-webhook.php
   ```
   Or for local testing with ngrok:
   ```
   https://your-ngrok-url.ngrok.io/project/php/paymongo-webhook.php
   ```
4. Select these events to listen to:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `payment_intent.awaiting_payment_method`
   - `payment.paid`
   - `payment.failed`
5. Copy the **Webhook Secret** (you'll need this for verification)

## Step 4: Update Configuration Files

### Update `project/php/paymongo-create.php`:
```php
define('PAYMONGO_SECRET_KEY', 'sk_test_YOUR_SECRET_KEY_HERE');
define('PAYMONGO_PUBLIC_KEY', 'pk_test_YOUR_PUBLIC_KEY_HERE');
```

### Update `project/php/paymongo-webhook.php`:
```php
define('PAYMONGO_WEBHOOK_SECRET', 'YOUR_WEBHOOK_SECRET_HERE');
```

### Update `project/api/config.php`:
```php
define('PAYMONGO_SECRET_KEY', 'sk_test_YOUR_SECRET_KEY_HERE');
define('PAYMONGO_PUBLIC_KEY', 'pk_test_YOUR_PUBLIC_KEY_HERE');
define('PAYMONGO_WEBHOOK_SECRET', 'YOUR_WEBHOOK_SECRET_HERE');
```

## Step 5: Update Frontend Code

The frontend is already set up to use PayMongo. You can call it like this:

```javascript
// In your checkout code
const paymentResult = await PaymentsAPI.createPayMongo(orderId, totalAmount);

if (paymentResult && paymentResult.success) {
    // Option 1: Redirect to PayMongo checkout page
    if (paymentResult.data.checkout_url) {
        window.location.href = paymentResult.data.checkout_url;
    }
    
    // Option 2: Use PayMongo JS SDK for embedded payment
    // (Requires additional setup with PayMongo JS SDK)
}
```

## Step 6: Supported Payment Methods

PayMongo supports:
- **GCash** - Mobile wallet
- **PayMaya** - Mobile wallet
- **Grab Pay** - Mobile wallet
- **Credit/Debit Cards** - Visa, Mastercard, etc.

All these are automatically enabled in the payment intent.

## Step 7: Testing

### Test Payment Flow:
1. Create an order through your customer portal
2. When payment is requested, it will create a PayMongo payment intent
3. Customer will be redirected to PayMongo checkout page
4. Use PayMongo test cards or test mobile wallets
5. Complete the payment
6. Webhook will update the order status automatically

### Test Cards (for card payments):
- **Success**: `4242 4242 4242 4242`
- **Declined**: `4000 0000 0000 0002`
- Use any future expiry date and any 3-digit CVC

## Step 8: Database Setup (Optional)

If you want to track payments separately, create a `payments` table:

```sql
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `paymongo_intent_id` varchar(255) DEFAULT NULL,
  `paymongo_link_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Paid','Failed','Cancelled') DEFAULT 'Pending',
  `metadata` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `paymongo_intent_id` (`paymongo_intent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
```

## Step 9: Local Development with Webhooks

For local development, you need to expose your local server:

1. **Using ngrok** (Recommended):
   ```bash
   ngrok http 8080
   ```
   Then use the ngrok URL in your webhook configuration

2. **Using localtunnel**:
   ```bash
   npx localtunnel --port 8080
   ```

## Step 10: Production Deployment

Before going live:

1. ✅ Switch to production API keys (`pk_live_` and `sk_live_`)
2. ✅ Update webhook URL to your production domain
3. ✅ Enable webhook signature verification (uncomment in `paymongo-webhook.php`)
4. ✅ Test with small real transactions first
5. ✅ Monitor webhook logs in PayMongo dashboard

## Troubleshooting

### Payment Intent Creation Fails
- Check that your API keys are correct
- Verify the amount is in PHP (will be converted to cents automatically)
- Check PayMongo dashboard for error logs

### Webhook Not Receiving Events
- Verify webhook URL is accessible
- Check webhook is enabled in PayMongo dashboard
- Verify webhook events are selected correctly
- Check server error logs

### Payment Status Not Updating
- Check webhook is being called (check PayMongo dashboard → Webhooks → Logs)
- Verify database connection
- Check that order_id in metadata matches your database

## Security Notes

1. **Never commit API keys to version control**
2. **Use environment variables for production**
3. **Enable webhook signature verification in production**
4. **Use HTTPS for webhook URLs**
5. **Regularly rotate your API keys**

## Support

- PayMongo Documentation: https://developers.paymongo.com
- PayMongo Support: support@paymongo.com
- PayMongo Dashboard: https://dashboard.paymongo.com

## QR Code Integration

If you want to display a QR code for payment (like the one you provided), you can:

1. Use PayMongo Payment Links which generate QR codes automatically
2. The checkout URL from `paymongo-create.php` can be converted to a QR code
3. Use a QR code library like `qrcode.js` to generate QR codes client-side

Example:
```javascript
// After getting payment result
const checkoutUrl = paymentResult.data.checkout_url;
// Generate QR code from checkoutUrl
```

