# Debugging PayMongo Payment Link Issue

## Issue: "Order created but payment link failed"

This error means the order was created successfully, but the PayMongo payment link creation failed.

## 🔍 Step-by-Step Debugging

### Step 1: Check Browser Console

1. Open the cashier manual order page
2. Press **F12** to open Developer Tools
3. Go to the **Console** tab
4. Try placing an order with PayMongo payment
5. Look for error messages - they will now show more details

**What to look for:**
- `Failed to create payment link:` - This will show the actual error
- `Payment creation error:` - This will show the exception details
- Any red error messages

### Step 2: Check Network Tab

1. In Developer Tools, go to **Network** tab
2. Try placing the order again
3. Look for the request to `/php/paymongo-create.php`
4. Click on it to see:
   - **Request Payload** - What was sent
   - **Response** - What was returned
   - **Status Code** - Should be 200, if not, that's the issue

**Common issues:**
- **404 Not Found** - The file path is wrong
- **500 Internal Server Error** - PHP error in the file
- **401 Unauthorized** - PayMongo API key issue
- **Response shows error message** - Check the error details

### Step 3: Check PHP Error Logs

Check your PHP error log (usually in XAMPP at `C:\xampp\apache\logs\error.log` or `C:\xampp\php\logs\php_error_log`)

Look for:
- `PayMongo: Failed to create payment link`
- `PayMongo: Payment link created but no checkout_url`
- Any PHP errors related to PayMongo

### Step 4: Test PayMongo API Directly

You can test if the PayMongo API is working by running this in your browser console:

```javascript
// Test if PaymentsAPI is available
console.log('PaymentsAPI:', typeof PaymentsAPI !== 'undefined' ? PaymentsAPI : 'NOT LOADED');

// Test creating a payment (replace with actual order_db_id)
if (typeof PaymentsAPI !== 'undefined') {
    PaymentsAPI.createPayMongo(1, 100)
        .then(result => {
            console.log('Payment Result:', result);
        })
        .catch(error => {
            console.error('Payment Error:', error);
        });
}
```

### Step 5: Verify PayMongo API Keys

1. Check `php/paymongo-create.php` lines 11-12
2. Verify the keys are correct:
   - Secret Key should start with `sk_live_` or `sk_test_`
   - Public Key should start with `pk_live_` or `pk_test_`
3. Make sure you're using the correct keys (test vs live)

### Step 6: Check PayMongo Dashboard

1. Go to [PayMongo Dashboard](https://dashboard.paymongo.com)
2. Check **API Keys** section
3. Verify your keys are active
4. Check **Webhooks** section for any failed webhook attempts

## 🛠️ Common Fixes

### Fix 1: API Keys Issue

**Problem:** Invalid or expired API keys

**Solution:**
1. Go to PayMongo Dashboard → Settings → API Keys
2. Generate new keys if needed
3. Update `php/paymongo-create.php` with new keys
4. Restart Apache

### Fix 2: CORS Issue

**Problem:** CORS headers not set correctly

**Solution:**
The file already has CORS headers, but if you're still getting CORS errors:
1. Check if Apache is running
2. Verify the file path is correct
3. Check browser console for CORS errors

### Fix 3: Payment Link Creation Fails

**Problem:** PayMongo API returns error when creating payment link

**Possible causes:**
- Invalid amount (must be at least 100 centavos = ₱1.00)
- Invalid currency
- API rate limiting
- PayMongo service issue

**Solution:**
1. Check the error message in browser console
2. Verify the amount is valid (minimum ₱1.00)
3. Check PayMongo status page
4. Try again after a few minutes

### Fix 4: PaymentsAPI Not Loaded

**Problem:** `PaymentsAPI.createPayMongo` is undefined

**Solution:**
1. Verify `api-helper.js` is loaded in the page
2. Check the HTML file includes:
   ```html
   <script src="../../assets/js/api-helper.js"></script>
   ```
3. Check browser console for JavaScript errors
4. Make sure the path to `api-helper.js` is correct

## 📋 Quick Diagnostic Checklist

Run through this checklist:

- [ ] Browser console shows detailed error (after my fix)
- [ ] Network tab shows the request to `paymongo-create.php`
- [ ] Response status is 200 (not 404, 500, etc.)
- [ ] PayMongo API keys are correct in `php/paymongo-create.php`
- [ ] `api-helper.js` is loaded (check Network tab)
- [ ] `PaymentsAPI` is available (check Console: `typeof PaymentsAPI`)
- [ ] Amount is at least ₱1.00
- [ ] PHP error logs don't show errors
- [ ] PayMongo Dashboard shows API keys are active

## 🧪 Test Directly

You can test the PayMongo API endpoint directly using curl:

```bash
curl -X POST http://localhost:8080/project (5)/project/php/paymongo-create.php \
  -H "Content-Type: application/json" \
  -d "{\"order_id\": 1, \"amount\": 100}"
```

Or use the test page:
```
http://localhost:8080/project (5)/project/test-paymongo-integration.html
```

## 📞 Next Steps

After checking the browser console with the improved error messages:

1. **Copy the exact error message** from the console
2. **Check the Network tab** response for `paymongo-create.php`
3. **Share the error details** so we can fix the specific issue

The improved error handling will now show:
- The exact error message from PayMongo
- Whether PaymentsAPI is loaded
- More detailed error information

---

**After my fixes, the error message will be more detailed and help identify the exact issue!**

