# Google OAuth Setup Guide

## Current Configuration
- **Client ID**: `1061892202770-pj41ss3hed6lgieprl98q9dnul6eedpk.apps.googleusercontent.com`
- **Client Secret**: `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`

## Quick Debug Tool

**Access the debug page to get your exact redirect URI:**
```
http://localhost:8080/project (5)/project/php/google-oauth-debug.php
```

This page will show you:
- The exact redirect URI (with spaces)
- The URL-encoded version (with %20)
- Step-by-step instructions
- Copy buttons for easy setup

## Fix "Error 400: invalid_request"

This error usually means the redirect URI doesn't match or the OAuth app needs configuration.

### Step 1: Find Your Exact Redirect URI

The redirect URI is built dynamically. To find your exact URI:

1. Open your browser's Developer Console (F12)
2. Go to Network tab
3. Click "Continue with Google" button
4. Look at the request to `google-auth.php`
5. Check the response - it will contain the `auth_url`
6. The redirect URI is in that URL (the `redirect_uri` parameter)

**Common redirect URIs:**
- `http://localhost:8080/project (5)/project/php/google-callback.php`
- `http://localhost/project (5)/project/php/google-callback.php`
- `http://127.0.0.1:8080/project (5)/project/php/google-callback.php`

### Step 2: Add Redirect URI to Google Cloud Console

1. Go to: https://console.cloud.google.com/apis/credentials
2. Click on your OAuth 2.0 Client ID
3. Under "Authorized redirect URIs", click "ADD URI"
4. Add **EXACTLY** the redirect URI from Step 1 (must match character-for-character)
5. Click "SAVE"

### Step 3: Configure OAuth Consent Screen

1. Go to: https://console.cloud.google.com/apis/credentials/consent
2. If not configured:
   - Choose "External" (for testing) or "Internal" (if using Google Workspace)
   - Fill in required fields:
     - App name: "Jessie Cane Juicebar"
     - User support email: Your email
     - Developer contact: Your email
   - Click "SAVE AND CONTINUE"
3. Add Test Users (if app is in Testing mode):
   - Click "ADD USERS"
   - Add: `rudgealkhent11@gmail.com`
   - Click "ADD"
   - Click "SAVE AND CONTINUE"

### Step 4: Verify App Status

- **Testing**: Only test users can sign in
- **In production**: Anyone can sign in (requires verification)

For development, keep it in "Testing" mode and add your email as a test user.

## Testing

After configuration:
1. Clear browser cache
2. Try "Continue with Google" again
3. You should be redirected to Google login
4. After login, you'll be redirected back to the app

## Troubleshooting

**Still getting Error 400?**
- Check that redirect URI matches EXACTLY (including http/https, port, path)
- Make sure there are no extra spaces or characters
- Verify the OAuth consent screen is configured
- If in Testing mode, ensure your email is added as a test user

**Error 403: access_denied?**
- App is in Testing mode and your email isn't added as a test user
- Add your email in OAuth consent screen → Test users

