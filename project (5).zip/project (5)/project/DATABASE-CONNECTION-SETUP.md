# Database Connection Setup - jessiecane (3).sql

This document explains how the system is now connected to the `jessiecane` database.

## Database Information

- **Database Name:** `jessiecane`
- **SQL File:** `jessiecane (3).sql`
- **Host:** `localhost`
- **Username:** `pma`
- **Password:** `Akolangnamanto123`

## Step 1: Import the Database

1. Open phpMyAdmin: `http://localhost:8080/phpmyadmin` (or `http://localhost:8081/phpmyadmin`)
2. Click on "New" to create a database (or use existing)
3. Database name: `jessiecane`
4. Click "Import" tab
5. Choose file: `project/jessiecane (3).sql`
6. Click "Go" to import

Alternatively, use command line:
```bash
mysql -u pma -p jessiecane < "C:\Users\rudge\Downloads\xampp2\htdocs\project (5)\project\jessiecane (3).sql"
```
(Enter password: `Akolangnamanto123`)

## Step 2: Verify Database Connection

All database connection files have been updated to use:
- Database: `jessiecane`
- Username: `pma`
- Password: `Akolangnamanto123`

### Database Connection Files Updated:
- ✅ `project/public/db_connect.php`
- ✅ `project/public/admin/db_connect.php`
- ✅ `project/public/cashier/db_connect.php`
- ✅ `project/public/cashier_fairview/db_connect.php`
- ✅ `project/public/cashier_sjdm/db_connect.php`
- ✅ `project/php/database.php`
- ✅ `project/php/config.php`
- ✅ `project/api/config/database.php`
- ✅ `project/api/config.php`

## Step 3: Login Credentials

### Admin Login
The admin login now checks the `users` table for users with `role = 'admin'`.

**To create an admin user:**
1. Go to phpMyAdmin
2. Select `jessiecane` database
3. Go to `users` table
4. Insert a new user with:
   - `role` = `'admin'`
   - `email` = your admin email
   - `password` = use `password_hash('yourpassword', PASSWORD_DEFAULT)` in PHP or hash it
   - `is_active` = `1`

**Fallback credentials (if no admin in database):**
- Email: `admin@jessiecane.com` or `admin` or `admin@gmail.com`
- Password: `admin123`

### Cashier Login

**Unified Cashier Portal** (`/cashier/login_cashier.php`):
- Email: `cashierfairview@gmail.com` → Password: `cashierfairview`
- Email: `cashiersjdm@gmail.com` → Password: `cashiersjdm`

**SM Fairview Cashier** (`/cashier_fairview/login_cashier.php`):
- Email: `cashierfairview@gmail.com`
- Password: `cashierfairview`

**SM San Jose del Monte Cashier** (`/cashier_sjdm/login_cashier.php`):
- Email: `cashiersjdm@gmail.com`
- Password: `cashiersjdm`

### Customer Login
Customers can register and login through the customer portal. Their credentials are stored in the `users` table with `role = 'customer'`.

## Database Tables

The database includes the following tables:
- `users` - Customer and admin accounts
- `cashiers` - Cashier accounts
- `products` - Product catalog
- `orders` - Order records
- `order_items` - Order line items
- `branches` - Branch information
- `cart` - Shopping cart
- `cart_items` - Cart items
- `inquiries` - Customer inquiries

## What Was Updated

1. ✅ All `db_connect.php` files now use `jessiecane` database
2. ✅ Admin login now queries `users` table for admin role
3. ✅ Cashier logins now use database passwords from `cashiers` table
4. ✅ All login files have proper error handling and output buffering
5. ✅ API config files updated to use correct database name
6. ✅ Fallback credentials match the database values

## Testing the Connection

1. **Test Admin Login:**
   - Go to: `http://localhost:8080/project%20(5)/project/public/admin/login_admin.php`
   - Use admin credentials from database or fallback

2. **Test Cashier Login:**
   - Go to: `http://localhost:8080/project%20(5)/project/public/cashier/login_cashier.php`
   - Use: `cashierfairview@gmail.com` / `cashierfairview`

3. **Test Database Connection:**
   - Go to: `http://localhost:8080/project%20(5)/project/php/test-connection.php`
   - Should show green checkmarks if connection is successful

## Troubleshooting

### Database Connection Failed
- Verify MySQL is running in XAMPP
- Check username/password in `db_connect.php` files
- Ensure database `jessiecane` exists
- Check Apache error log: `C:\xampp\apache\logs\error.log`

### Login Not Working
- Verify the database was imported correctly
- Check if user exists in `users` or `cashiers` table
- Check browser console (F12) for JavaScript errors
- Verify PHP error reporting is enabled for debugging

### Wrong Database Name
If you see errors about database not found, ensure all files use `jessiecane` (not `jessie_cane_db` or other variations).

## Notes

- All passwords in the `cashiers` table are stored as plain text (as per the SQL file)
- User passwords in the `users` table are hashed with bcrypt
- The system will fall back to hardcoded credentials if database connection fails
- Make sure to import `jessiecane (3).sql` (not the other SQL files) for the correct structure

