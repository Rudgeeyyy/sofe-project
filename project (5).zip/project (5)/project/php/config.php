<?php
$host = "localhost";
$user = "pma";
$pass = "Akolangnamanto123";
$dbname = "jessiecane"; // must match the one you just created

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
