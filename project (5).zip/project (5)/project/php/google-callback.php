<?php
session_start();

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

// Google OAuth Configuration
define('GOOGLE_CLIENT_ID', '1061892202770-pj41ss3hed6lgieprl98q9dnul6eedpk.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');

// Dynamically build redirect URI and frontend domain
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$path = dirname(dirname($_SERVER['SCRIPT_NAME']));

// URL-encode each path segment to handle spaces (must match what we send to Google)
$pathSegments = explode('/', trim($path, '/'));
$encodedSegments = array_map('rawurlencode', $pathSegments);
$encodedPath = '/' . implode('/', $encodedSegments);

// Build redirect URI with URL-encoded path (must match exactly what's in Google Console)
$redirectUri = $protocol . '://' . $host . $encodedPath . '/php/google-callback.php';
$frontendDomain = $protocol . '://' . $host . $encodedPath . '/public/customer';

if (!isset($_GET['code'])) {
    header('Location: ' . $frontendDomain . '/customer_dashboard.php?auth=error&message=No authorization code received');
    exit;
}

$code = $_GET['code'];

// Use the same redirect URI we built (which matches what we sent to Google in google-auth.php)
// This must match EXACTLY what's registered in Google Console
$redirectUriForToken = $redirectUri;

// Log for debugging
error_log('Google Callback - Using redirect URI: ' . $redirectUriForToken);
error_log('Google Callback - SCRIPT_NAME: ' . $_SERVER['SCRIPT_NAME']);
error_log('Google Callback - REQUEST_URI: ' . ($_SERVER['REQUEST_URI'] ?? 'N/A'));

// Exchange authorization code for access token
$tokenUrl = 'https://oauth2.googleapis.com/token';

// Trim credentials to remove any accidental whitespace
$clientId = trim(GOOGLE_CLIENT_ID);
$clientSecret = trim(GOOGLE_CLIENT_SECRET);

// Log credentials (without exposing the full secret)
error_log('Google Token Exchange - Client ID: ' . $clientId);
error_log('Google Token Exchange - Client Secret (first 10 chars): ' . substr($clientSecret, 0, 10) . '...');
error_log('Google Token Exchange - Redirect URI: ' . $redirectUriForToken);

$tokenData = [
    'code' => $code,
    'client_id' => $clientId,
    'client_secret' => $clientSecret,
    'redirect_uri' => $redirectUriForToken,
    'grant_type' => 'authorization_code'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $tokenUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

$tokenResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// Log the response for debugging
error_log('Google Token Exchange - HTTP Code: ' . $httpCode);
error_log('Google Token Exchange - Response: ' . $tokenResponse);
if ($curlError) {
    error_log('Google Token Exchange - cURL Error: ' . $curlError);
}

if ($httpCode !== 200) {
    $errorData = json_decode($tokenResponse, true);
    $errorMessage = $errorData['error_description'] ?? $errorData['error'] ?? 'Failed to exchange code for token';
    $errorCode = $errorData['error'] ?? 'unknown_error';
    
    // Log detailed error information
    error_log('Google Token Exchange Failed:');
    error_log('  HTTP Code: ' . $httpCode);
    error_log('  Error: ' . $errorCode);
    error_log('  Error Description: ' . $errorMessage);
    error_log('  Redirect URI used: ' . $redirectUriForToken);
    error_log('  Full response: ' . $tokenResponse);
    
    // Create a more detailed error message for the user
    $userFriendlyMessage = $errorMessage;
    if ($errorCode === 'invalid_grant') {
        $userFriendlyMessage = 'Authorization code expired or already used. Please try logging in again.';
    } elseif ($errorCode === 'redirect_uri_mismatch') {
        $userFriendlyMessage = 'Redirect URI mismatch. Please check Google Cloud Console settings.';
    } elseif ($httpCode === 401) {
        $userFriendlyMessage = 'Invalid client credentials. Please check your Google OAuth settings.';
    }
    
    header('Location: ' . $frontendDomain . '/customer_dashboard.php?auth=error&message=' . urlencode($userFriendlyMessage) . '&code=' . urlencode($errorCode));
    exit;
}

$tokenData = json_decode($tokenResponse, true);
$accessToken = $tokenData['access_token'] ?? null;

if (!$accessToken) {
    header('Location: ' . $frontendDomain . '/customer_dashboard.php?auth=error&message=No access token received');
    exit;
}

// Get user info from Google
$userInfoUrl = 'https://www.googleapis.com/oauth2/v2/userinfo';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $userInfoUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);

$userInfoResponse = curl_exec($ch);
curl_close($ch);

$userInfo = json_decode($userInfoResponse, true);

if (!$userInfo || !isset($userInfo['email'])) {
    header('Location: ' . $frontendDomain . '/customer_dashboard.php?auth=error&message=Failed to get user information');
    exit;
}

// Check if user exists in database
$database = new Database();
$db = $database->getConnection();

if (!$db) {
    header('Location: ' . $frontendDomain . '/customer_dashboard.php?auth=error&message=Database connection failed');
    exit;
}

$googleId = $userInfo['id'] ?? null;
$email = $userInfo['email'] ?? null;
$fullName = $userInfo['name'] ?? $userInfo['email'];
$picture = $userInfo['picture'] ?? null;

// Split name into firstname and lastname
$nameParts = explode(' ', trim($fullName), 2);
$firstname = $nameParts[0] ?? '';
$lastname = $nameParts[1] ?? '';

// Check if google_id column exists in users table
$checkColumnQuery = "SHOW COLUMNS FROM users LIKE 'google_id'";
$columnCheck = $db->query($checkColumnQuery);
$hasGoogleIdColumn = $columnCheck && $columnCheck->rowCount() > 0;

// Find existing user by email or google_id (if column exists)
if ($hasGoogleIdColumn && $googleId) {
    $query = "SELECT * FROM users WHERE google_id = :google_id OR email = :email LIMIT 1";
} else {
    $query = "SELECT * FROM users WHERE email = :email LIMIT 1";
}

$stmt = $db->prepare($query);
if ($hasGoogleIdColumn && $googleId) {
    $stmt->bindParam(':google_id', $googleId);
}
$stmt->bindParam(':email', $email);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Create new user
    $username = strtolower(preg_replace('/[^a-z0-9]/', '', $fullName)) . rand(100, 999);
    
    if ($hasGoogleIdColumn && $googleId) {
        $insertQuery = "INSERT INTO users (firstname, lastname, username, email, google_id, role, password) 
                       VALUES (:firstname, :lastname, :username, :email, :google_id, 'customer', :password)";
    } else {
        $insertQuery = "INSERT INTO users (firstname, lastname, username, email, role, password) 
                       VALUES (:firstname, :lastname, :username, :email, 'customer', :password)";
    }
    
    $insertStmt = $db->prepare($insertQuery);
    $insertStmt->bindParam(':firstname', $firstname);
    $insertStmt->bindParam(':lastname', $lastname);
    $insertStmt->bindParam(':username', $username);
    $insertStmt->bindParam(':email', $email);
    $password = password_hash(uniqid(), PASSWORD_DEFAULT); // Random password for Google users
    $insertStmt->bindParam(':password', $password);
    
    if ($hasGoogleIdColumn && $googleId) {
        $insertStmt->bindParam(':google_id', $googleId);
    }
    
    $insertStmt->execute();
    $userId = $db->lastInsertId();
    
    // Fetch the created user to get all fields
    $fetchQuery = "SELECT user_id, firstname, lastname, username, email, role FROM users WHERE user_id = :user_id";
    $fetchStmt = $db->prepare($fetchQuery);
    $fetchStmt->bindParam(':user_id', $userId);
    $fetchStmt->execute();
    $user = $fetchStmt->fetch(PDO::FETCH_ASSOC);
} else {
    // Update google_id if column exists and not set
    if ($hasGoogleIdColumn && $googleId && empty($user['google_id'])) {
        $updateQuery = "UPDATE users SET google_id = :google_id WHERE user_id = :user_id";
        $updateStmt = $db->prepare($updateQuery);
        $updateStmt->bindParam(':google_id', $googleId);
        $updateStmt->bindParam(':user_id', $user['user_id']);
        $updateStmt->execute();
    }
}

// Generate token and redirect (use user_id instead of id)
$token = base64_encode(json_encode(['user_id' => $user['user_id'], 'role' => $user['role'] ?? 'customer']));

header('Location: ' . $frontendDomain . '/customer_dashboard.php?auth=success&token=' . urlencode($token));
exit;
?>

