<?php
require_once __DIR__ . '/database.php';

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function generateOrderId($db = null) {
    // Generate a more unique order ID using timestamp + random number
    // Format: ORD-YYYYMMDD-HHMMSS-RRRR (where RRRR is random 4 digits)
    $timestamp = time();
    $datePart = date('Ymd', $timestamp);
    $timePart = date('His', $timestamp);
    $randomPart = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
    $orderId = 'ORD-' . $datePart . '-' . $timePart . '-' . $randomPart;
    
    // If database connection is provided, check for duplicates and retry if needed
    if ($db) {
        $maxRetries = 10;
        $retryCount = 0;
        
        while ($retryCount < $maxRetries) {
            // Check if order ID already exists
            $checkQuery = "SELECT COUNT(*) as count FROM orders WHERE order_id = :order_id";
            $checkStmt = $db->prepare($checkQuery);
            $checkStmt->bindParam(':order_id', $orderId);
            $checkStmt->execute();
            $result = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result && $result['count'] == 0) {
                // Order ID is unique, return it
                return $orderId;
            }
            
            // If duplicate found, generate a new one with different random part
            $randomPart = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
            $orderId = 'ORD-' . $datePart . '-' . $timePart . '-' . $randomPart;
            $retryCount++;
        }
        
        // If we still have duplicates after retries, add microseconds for extra uniqueness
        $microseconds = str_pad(substr(microtime(true) * 10000, -4), 4, '0', STR_PAD_LEFT);
        $orderId = 'ORD-' . $datePart . '-' . $timePart . '-' . $microseconds;
    }
    
    return $orderId;
}

function verifyToken($token) {
    // Implement JWT token verification here
    // For now, return user ID from token
    return null;
}
?>

