<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$userId = $_GET['user_id'] ?? null;

if (!$userId) {
    sendError('User ID is required');
}

$database = new Database();
$db = $database->getConnection();

// Use user_id instead of id, and firstname/lastname instead of name
$query = "SELECT user_id, firstname, lastname, username, email, phone, address, role, date_created FROM users WHERE user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $userId);
$stmt->execute();

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    sendError('User not found', 404);
}

// Combine firstname and lastname into name for compatibility
$user['name'] = trim(($user['firstname'] ?? '') . ' ' . ($user['lastname'] ?? ''));
$user['id'] = $user['user_id']; // Add id alias for compatibility

// Get user's orders count
$ordersQuery = "SELECT COUNT(*) as order_count FROM orders WHERE user_id = :user_id";
$ordersStmt = $db->prepare($ordersQuery);
$ordersStmt->bindParam(':user_id', $userId);
$ordersStmt->execute();
$orderData = $ordersStmt->fetch(PDO::FETCH_ASSOC);
$user['order_count'] = $orderData['order_count'] ?? 0;

sendResponse(true, 'User profile retrieved successfully', $user);
?>

