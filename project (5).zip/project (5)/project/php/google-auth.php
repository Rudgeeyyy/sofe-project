<?php
session_start();

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Google OAuth Configuration
// Get your credentials from: https://console.cloud.google.com/apis/credentials
define('GOOGLE_CLIENT_ID', '1061892202770-pj41ss3hed6lgieprl98q9dnul6eedpk.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');

// Dynamically build redirect URI based on current host
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$path = dirname(dirname($_SERVER['SCRIPT_NAME']));

// URL-encode each path segment to handle spaces (Google doesn't allow spaces in redirect URIs)
$pathSegments = explode('/', trim($path, '/'));
$encodedSegments = array_map('rawurlencode', $pathSegments);
$encodedPath = '/' . implode('/', $encodedSegments);

// Build redirect URI with URL-encoded path
$redirectUri = $protocol . '://' . $host . $encodedPath . '/php/google-callback.php';

// Log the redirect URI for debugging
error_log('Google OAuth Redirect URI: ' . $redirectUri);

// Google OAuth2 authorization endpoint
$authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
    'client_id' => GOOGLE_CLIENT_ID,
    'redirect_uri' => $redirectUri,
    'response_type' => 'code',
    'scope' => 'openid email profile',
    'access_type' => 'online',
    'prompt' => 'select_account'
]);

// Check if credentials are configured
if (GOOGLE_CLIENT_ID === 'YOUR_GOOGLE_CLIENT_ID' || GOOGLE_CLIENT_SECRET === 'YOUR_GOOGLE_CLIENT_SECRET') {
    sendError('Google OAuth credentials not configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in php/google-auth.php', 500);
    exit;
}

sendResponse(true, 'Google auth URL generated', [
    'auth_url' => $authUrl,
    'redirect_uri' => $redirectUri // This is the URL-encoded version (spaces become %20) - use this exact URI in Google Console
]);
?>
