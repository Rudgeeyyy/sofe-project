<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$database = new Database();
$db = $database->getConnection();

// Get query parameters for filtering
$branch = $_GET['branch'] ?? null;
$status = $_GET['status'] ?? null;
$user_id = $_GET['user_id'] ?? null;
$order_type = $_GET['order_type'] ?? null;

$query = "SELECT o.*, 
          GROUP_CONCAT(
              CONCAT(oi.product_name, ' (', oi.size, ') x', oi.quantity) 
              SEPARATOR ', '
          ) as items_summary
          FROM orders o
          LEFT JOIN order_items oi ON o.id = oi.order_id";

$conditions = [];
$params = [];

if ($branch) {
    $conditions[] = "o.branch = :branch";
    $params[':branch'] = $branch;
}

if ($status) {
    $conditions[] = "o.order_status = :status";
    $params[':status'] = $status;
}

if ($user_id) {
    $conditions[] = "o.user_id = :user_id";
    $params[':user_id'] = intval($user_id);
}

if ($order_type) {
    $conditions[] = "o.order_type = :order_type";
    $params[':order_type'] = $order_type;
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " GROUP BY o.id ORDER BY o.timestamp DESC, o.order_date DESC";

$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();

$orders = $stmt->fetchAll();

// Get order items for each order
foreach ($orders as &$order) {
    $itemsQuery = "SELECT * FROM order_items WHERE order_id = :order_id";
    $itemsStmt = $db->prepare($itemsQuery);
    $itemsStmt->bindParam(':order_id', $order['id']);
    $itemsStmt->execute();
    $order['items'] = $itemsStmt->fetchAll();
}

sendResponse(true, 'Orders retrieved successfully', $orders);
?>

