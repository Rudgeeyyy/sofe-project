<?php
/**
 * Google OAuth Credentials Test Page
 * This page helps verify that your Google OAuth credentials are correctly configured
 */

// Google OAuth Configuration
define('GOOGLE_CLIENT_ID', '1061892202770-pj41ss3hed6lgieprl98q9dnul6eedpk.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');

// Build redirect URI
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$path = dirname(dirname($_SERVER['SCRIPT_NAME']));
$pathSegments = explode('/', trim($path, '/'));
$encodedSegments = array_map('rawurlencode', $pathSegments);
$encodedPath = '/' . implode('/', $encodedSegments);
$redirectUri = $protocol . '://' . $host . $encodedPath . '/php/google-callback.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Google OAuth Credentials Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        h1 { color: #333; }
        .info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 4px;
            border-left: 4px solid #2196f3;
            margin: 10px 0;
        }
        .success {
            background: #e8f5e9;
            border-left: 4px solid #4caf50;
        }
        .error {
            background: #ffebee;
            border-left: 4px solid #f44336;
        }
        .warning {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        code {
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
            word-break: break-all;
        }
        .credential {
            background: #f9f9f9;
            padding: 10px;
            margin: 5px 0;
            border-radius: 4px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="box">
        <h1>🔍 Google OAuth Credentials Test</h1>
        
        <div class="info">
            <h3>Current Configuration:</h3>
            <p><strong>Client ID:</strong></p>
            <div class="credential"><?php echo htmlspecialchars(GOOGLE_CLIENT_ID); ?></div>
            
            <p><strong>Client Secret:</strong> (first 15 characters shown)</p>
            <div class="credential"><?php echo htmlspecialchars(substr(GOOGLE_CLIENT_SECRET, 0, 15)) . '...'; ?></div>
            
            <p><strong>Redirect URI:</strong></p>
            <div class="credential"><?php echo htmlspecialchars($redirectUri); ?></div>
        </div>
        
        <div class="info warning">
            <h3>⚠️ Verification Steps:</h3>
            <ol>
                <li>Go to <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console - Credentials</a></li>
                <li>Find your OAuth 2.0 Client ID: <code><?php echo htmlspecialchars(GOOGLE_CLIENT_ID); ?></code></li>
                <li>Click on it to view details</li>
                <li>Verify:
                    <ul>
                        <li>The <strong>Client ID</strong> matches exactly: <code><?php echo htmlspecialchars(GOOGLE_CLIENT_ID); ?></code></li>
                        <li>The <strong>Client secret</strong> matches (check the first few characters)</li>
                        <li>The <strong>Authorized redirect URIs</strong> includes: <code><?php echo htmlspecialchars($redirectUri); ?></code></li>
                        <li>The OAuth app is <strong>enabled</strong> (not deleted or disabled)</li>
                    </ul>
                </li>
            </ol>
        </div>
        
        <div class="info">
            <h3>📝 Common Issues:</h3>
            <ul>
                <li><strong>Invalid client credentials:</strong> Usually means the Client ID and Secret don't match, or the OAuth app was deleted/disabled</li>
                <li><strong>Redirect URI mismatch:</strong> The redirect URI in your code must match EXACTLY what's in Google Console (including URL encoding)</li>
                <li><strong>OAuth app not enabled:</strong> Make sure your OAuth app is active in Google Cloud Console</li>
            </ul>
        </div>
        
        <div class="info">
            <h3>🧪 Test Your Setup:</h3>
            <p>After verifying your credentials in Google Cloud Console:</p>
            <ol>
                <li>Make sure the redirect URI above is added to Google Console</li>
                <li>Go to your customer dashboard</li>
                <li>Try logging in with Google</li>
                <li>Check the PHP error log for detailed error messages</li>
            </ol>
        </div>
        
        <div class="info">
            <h3>📋 Copy Redirect URI:</h3>
            <button onclick="copyRedirectUri()" style="padding: 10px 20px; background: #4285f4; color: white; border: none; border-radius: 4px; cursor: pointer;">
                📋 Copy Redirect URI to Clipboard
            </button>
            <p id="copyStatus" style="margin-top: 10px;"></p>
        </div>
    </div>
    
    <script>
        function copyRedirectUri() {
            const uri = '<?php echo htmlspecialchars($redirectUri, ENT_QUOTES); ?>';
            navigator.clipboard.writeText(uri).then(() => {
                document.getElementById('copyStatus').textContent = '✅ Redirect URI copied!';
                document.getElementById('copyStatus').style.color = '#4caf50';
            }).catch(err => {
                // Fallback
                const textarea = document.createElement('textarea');
                textarea.value = uri;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                document.getElementById('copyStatus').textContent = '✅ Redirect URI copied!';
                document.getElementById('copyStatus').style.color = '#4caf50';
            });
        }
    </script>
</body>
</html>

