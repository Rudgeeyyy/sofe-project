<?php
// Simple debug page to show the exact redirect URI
// Access this at: http://localhost:8080/project (5)/project/php/google-oauth-debug.php

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$path = dirname(dirname($_SERVER['SCRIPT_NAME']));

// URL-encode each path segment to handle spaces (Google doesn't allow spaces in redirect URIs)
$pathSegments = explode('/', trim($path, '/'));
$encodedSegments = array_map('rawurlencode', $pathSegments);
$encodedPath = '/' . implode('/', $encodedSegments);

// Build redirect URI with URL-encoded path (this is what Google requires)
$redirectUri = $protocol . '://' . $host . $encodedPath . '/php/google-callback.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Google OAuth Debug - Redirect URI</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        h1 { color: #333; }
        .uri {
            background: #f0f0f0;
            padding: 15px;
            border-radius: 4px;
            font-family: monospace;
            word-break: break-all;
            margin: 10px 0;
            border-left: 4px solid #4285f4;
        }
        .instructions {
            background: #e8f5e9;
            padding: 15px;
            border-radius: 4px;
            border-left: 4px solid #4caf50;
        }
        .instructions ol {
            margin: 10px 0;
            padding-left: 20px;
        }
        .instructions li {
            margin: 8px 0;
        }
        .copy-btn {
            background: #4285f4;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .copy-btn:hover {
            background: #357ae8;
        }
    </style>
</head>
<body>
    <div class="box">
        <h1>🔗 Google OAuth Redirect URI</h1>
        <p><strong>✅ This redirect URI is properly URL-encoded (spaces are %20)</strong></p>
        <p>Copy this <strong>exact</strong> redirect URI and add it to your Google Cloud Console:</p>
        <div class="uri" id="redirectUri" style="background: #e8f5e9; border-left: 4px solid #4caf50;"><?php echo htmlspecialchars($redirectUri); ?></div>
        <button class="copy-btn" onclick="copyToClipboard()">📋 Copy Redirect URI</button>
        
        <div style="margin-top: 20px; padding: 15px; background: #e3f2fd; border-left: 4px solid #2196f3; border-radius: 4px;">
            <strong>ℹ️ Note:</strong> This URI has spaces URL-encoded as <code>%20</code> (e.g., <code>project%20(5)</code> instead of <code>project (5)</code>). 
            This is required because Google OAuth doesn't accept spaces in redirect URIs.
        </div>
    </div>

    <div class="box instructions">
        <h2>📝 How to Add This to Google Cloud Console:</h2>
        <ol>
            <li>Go to: <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console - Credentials</a></li>
            <li>Click on your OAuth 2.0 Client ID: <code>1061892202770-pj41ss3hed6lgieprl98q9dnul6eedpk.apps.googleusercontent.com</code></li>
            <li>Scroll down to <strong>"Authorized redirect URIs"</strong></li>
            <li>Click <strong>"ADD URI"</strong></li>
            <li>Paste the redirect URI above (or click the copy button)</li>
            <li>Click <strong>"SAVE"</strong></li>
        </ol>
    </div>

    <div class="box instructions">
        <h2>⚙️ OAuth Consent Screen Setup:</h2>
        <ol>
            <li>Go to: <a href="https://console.cloud.google.com/apis/credentials/consent" target="_blank">OAuth Consent Screen</a></li>
            <li>If not configured:
                <ul>
                    <li>Choose <strong>"External"</strong> (for testing)</li>
                    <li>Fill in required fields (App name, Support email, Developer contact)</li>
                    <li>Click <strong>"SAVE AND CONTINUE"</strong></li>
                </ul>
            </li>
            <li>Add Test Users (if app is in Testing mode):
                <ul>
                    <li>Click <strong>"ADD USERS"</strong></li>
                    <li>Add: <code>rudgealkhent11@gmail.com</code></li>
                    <li>Click <strong>"SAVE"</strong></li>
                </ul>
            </li>
        </ol>
    </div>

    <div class="box">
        <h2>🧪 Test Google OAuth:</h2>
        <p>After adding the redirect URI and configuring the consent screen:</p>
        <a href="../public/customer/customer_dashboard.php" style="display: inline-block; background: #4285f4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Go to Customer Dashboard → Try Google Login</a>
    </div>

    <script>
        function copyToClipboard() {
            const uri = document.getElementById('redirectUri').textContent;
            navigator.clipboard.writeText(uri).then(() => {
                alert('✅ Redirect URI copied to clipboard!\n\nNow paste it in Google Cloud Console → OAuth 2.0 Client ID → Authorized redirect URIs');
            }).catch(err => {
                // Fallback for older browsers
                const textarea = document.createElement('textarea');
                textarea.value = uri;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                alert('✅ Redirect URI copied to clipboard!\n\nNow paste it in Google Cloud Console → OAuth 2.0 Client ID → Authorized redirect URIs');
            });
        }
        
    </script>
</body>
</html>

