# Testing PayMongo Integration

## Quick Test Guide

### Step 1: Verify Configuration

Make sure these files have your PayMongo keys:
- ✅ `project/php/paymongo-create.php` - Has your secret and public keys
- ✅ `project/php/paymongo-webhook.php` - Has your webhook secret
- ✅ `project/api/config.php` - Has all keys configured

### Step 2: Set Up Webhook (IMPORTANT!)

1. Go to [PayMongo Dashboard](https://dashboard.paymongo.com)
2. Navigate to **Settings** → **Webhooks**
3. Create or edit your webhook
4. Set the webhook URL to:
   ```
   http://localhost:8080/project%20(5)/project/php/paymongo-webhook.php
   ```
   Or if you have a public domain:
   ```
   https://your-domain.com/project/php/paymongo-webhook.php
   ```
5. Select these events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `payment_intent.awaiting_payment_method`
   - `payment.paid`
   - `payment.failed`

### Step 3: Test Payment Flow

1. **Open Customer Portal:**
   ```
   http://localhost:8080/project%20(5)/project/public/customer/drinks.php
   ```

2. **Add Items to Cart:**
   - Select some drinks
   - Add to cart
   - Click "Checkout" or "Place Order"

3. **Complete Order Form:**
   - Enter customer name
   - Enter email and phone
   - Select branch
   - Click "Place Order"

4. **Payment Redirect:**
   - You should be redirected to PayMongo checkout page
   - You'll see payment options: GCash, PayMaya, Grab Pay, or Card

5. **Test Payment:**
   - **For GCash/PayMaya/Grab Pay:** Use test accounts or real accounts (will charge real money with live keys!)
   - **For Card:** Use test card: `4242 4242 4242 4242` with any future expiry and any CVC

### Step 4: Verify Payment

1. **Check PayMongo Dashboard:**
   - Go to **Payments** section
   - You should see the payment attempt
   - Check status (Pending, Paid, Failed)

2. **Check Webhook:**
   - Go to **Webhooks** → **Logs**
   - You should see webhook events being sent
   - Check if they're successful (200 status)

3. **Check Your Database:**
   - Check the `orders` table
   - Payment status should update to "Paid" when payment succeeds
   - Order status should update to "Approved"

### Step 5: Test Different Scenarios

#### Test Successful Payment:
- Complete payment with valid test card or mobile wallet
- Verify order status updates to "Paid" and "Approved"

#### Test Failed Payment:
- Use declined card: `4000 0000 0000 0002`
- Verify order status shows "Failed"

#### Test Cancelled Payment:
- Start payment but cancel/close the window
- Verify order remains "Pending"

## Troubleshooting

### Payment Intent Creation Fails

**Check:**
1. API keys are correct in `paymongo-create.php`
2. Amount is valid (greater than 0)
3. Order exists in database
4. Check browser console for errors
5. Check PHP error logs: `C:\xampp\apache\logs\error.log`

**Common Errors:**
- `401 Unauthorized` - Wrong API keys
- `400 Bad Request` - Invalid data format
- `404 Not Found` - Order not found

### Webhook Not Working

**Check:**
1. Webhook URL is accessible (use ngrok for local testing)
2. Webhook secret is correct
3. Webhook events are selected
4. Check PayMongo Dashboard → Webhooks → Logs

**For Local Testing:**
```bash
# Install ngrok
# Then run:
ngrok http 8080

# Use the ngrok URL in webhook configuration:
https://your-ngrok-url.ngrok.io/project/php/paymongo-webhook.php
```

### Payment Redirect Not Working

**Check:**
1. `checkout_url` is in the response
2. JavaScript console for errors
3. Network tab to see API response

## Test Checklist

- [ ] Configuration files have correct API keys
- [ ] Webhook is configured in PayMongo Dashboard
- [ ] Webhook URL is accessible
- [ ] Can create order successfully
- [ ] Payment intent is created
- [ ] Redirects to PayMongo checkout
- [ ] Can complete test payment
- [ ] Webhook receives events
- [ ] Order status updates in database
- [ ] Payment appears in PayMongo Dashboard

## Important Notes

⚠️ **You're using LIVE keys!** These will process REAL payments and charge REAL money.

- Test with small amounts first
- Monitor transactions in PayMongo Dashboard
- Keep your secret keys secure
- Don't commit keys to version control

## Need Help?

- Check PayMongo Dashboard for payment logs
- Check browser console for JavaScript errors
- Check PHP error logs for server errors
- Check PayMongo webhook logs for webhook issues

