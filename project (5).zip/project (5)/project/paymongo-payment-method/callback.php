<?php
// PayMongo Payment Method Callback - Integrated with main system
// This callback should use the main webhook handler at php/paymongo-webhook.php
// This file is kept for backward compatibility but redirects to main handler

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// For webhook events, use the main system's webhook handler
// The main webhook handler at php/paymongo-webhook.php handles:
// - payment_intent.succeeded
// - payment_intent.payment_failed
// - payment.paid
// - payment.failed

// This callback file can be used for direct payment link callbacks
$input = file_get_contents("php://input");
$event = json_decode($input, true);

// If this is a webhook event, log it and respond
if (isset($event['data']['attributes']['status'])) {
    $status = $event['data']['attributes']['status'];
    $paymentId = $event['data']['id'] ?? 'unknown';
    
    // Log the event
    $logMessage = date('Y-m-d H:i:s') . " - Payment ID: $paymentId - Status: $status\n";
    file_put_contents(__DIR__ . "/payments.log", $logMessage, FILE_APPEND);
    
    // For successful payments, you might want to update order status
    if ($status == "paid") {
        // Note: Order status updates should be handled by the main webhook handler
        // This is just for logging purposes
    }
}

// Respond with a 200 OK
http_response_code(200);
echo json_encode(['success' => true, 'message' => 'Callback received']);