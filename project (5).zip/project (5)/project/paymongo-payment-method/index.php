<?php
// Get order information from URL parameters (if provided)
$orderId = $_GET['order_id'] ?? '';
$orderDbId = $_GET['order_db_id'] ?? '';
$total = isset($_GET['total']) ? floatval($_GET['total']) : 0;
$customerName = $_GET['customer_name'] ?? '';
$description = $orderId ? 'Order ' . htmlspecialchars($orderId) : 'Payment';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayMongo Payment - <?php echo $orderId ? htmlspecialchars($orderId) : 'Complete Payment'; ?></title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap');

         * {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;    
         }

         body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: linear-gradient(to right, #43e97b 0%, #38f9d7 100%);
            padding: 20px;
         }

         .container {
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
            background-color: #fff;
            max-width: 500px;
            width: 100%;
         }

         form {
            display: flex;
            flex-direction: column;
            gap: 15px;
         }

         h2 {
            font-size: 30px;
            margin-bottom: 10px;
            color: #009039;
         }

         .order-info {
            background: #f8f5e9;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: left;
        }

         .order-info p {
            margin: 5px 0;
            font-size: 14px;
         }

         .order-info strong {
            color: #009039;
        }

         label {
            text-align: left;
            font-weight: 500;
            color: #333;
            margin-bottom: 5px;
         }

         input {
            text-align: center;
            font-size: 20px;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s;
         }

         input:focus {
            border-color: #009039;
         }

         button {
            font-size: 18px;
            padding: 12px;
            background-color: #009039;
            border: none;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

         button:hover {
            background-color: #00bf4c;
        }

         .min-note {
            font-size: 12px;
            color: #666;
            margin-top: -10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Complete Your Payment</h2>
        
        <?php if ($orderId): ?>
            <div class="order-info">
                <p><strong>Order ID:</strong> <?php echo htmlspecialchars($orderId); ?></p>
                <?php if ($customerName): ?>
                    <p><strong>Customer:</strong> <?php echo htmlspecialchars($customerName); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <form action="create_payment.php" method="POST">
            <!-- Hidden fields for order information -->
            <?php if ($orderId): ?>
                <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($orderId); ?>">
            <?php endif; ?>
            <?php if ($orderDbId): ?>
                <input type="hidden" name="order_db_id" value="<?php echo htmlspecialchars($orderDbId); ?>">
            <?php endif; ?>
            <?php if ($customerName): ?>
                <input type="hidden" name="customer_name" value="<?php echo htmlspecialchars($customerName); ?>">
            <?php endif; ?>
            
            <div>
                <label for="amount">Amount (PHP):</label>
                <input type="number" name="amount" id="amount" 
                       value="<?php echo $total > 0 ? number_format($total, 2, '.', '') : ''; ?>" 
                       min="1" step="0.01" required>
                <p class="min-note">Minimum: ₱100.00 (PayMongo requirement)</p>
            </div>
            
            <div>
                <label for="description">Description:</label>
                <input type="text" name="description" id="description" 
                       value="<?php echo htmlspecialchars($description); ?>" 
                       placeholder="Payment description">
            </div>
            
            <button type="submit">
                <i class="fa-solid fa-credit-card"></i> Pay Now
            </button>
        </form>
    </div>
</body>
</html>
