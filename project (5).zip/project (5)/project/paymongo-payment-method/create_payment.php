<?php
// PayMongo Payment Method - Integrated with main system
// This file uses the same configuration as php/paymongo-create.php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Use the same configuration as the main system
// PayMongo Configuration - Get from: https://dashboard.paymongo.com/settings/api-keys
define('PAYMONGO_SECRET_KEY', 'sk_live_EcNSvL5xN9UeTNseJfJLGLty'); // Live Secret Key
define('PAYMONGO_PUBLIC_KEY', 'pk_live_D8zvMEySLLPxz1KKnbmg96xS'); // Live Public Key
define('PAYMONGO_API_URL', 'https://api.paymongo.com/v1');

// ⚠️ LIVE KEYS - These will process REAL payments!
// Make sure your webhook URL is set to production domain

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Collect form data
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$description = isset($_POST['description']) ? trim($_POST['description']) : 'Payment';
$remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';

// Get order information if provided
$orderId = $_POST['order_id'] ?? null;
$orderDbId = $_POST['order_db_id'] ?? null;
$customerName = $_POST['customer_name'] ?? '';

if ($amount <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid amount']);
    exit;
}

// Minimum amount check (PayMongo API requires ₱100.00 minimum)
if ($amount < 100) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Minimum payment is ₱100.00 (PayMongo requirement)']);
    exit;
}

// Convert amount to cents (PayMongo uses smallest currency unit)
$amountInCents = intval($amount * 100);

// Define the data payload for creating a Payment Link
$data = [
    "data" => [
        "attributes" => [
            "amount" => $amountInCents,
            "currency" => "PHP",
            "description" => $description,
            "remarks" => $remarks
        ]
    ]
];

// Initialize cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, PAYMONGO_API_URL . "/links");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_USERPWD, PAYMONGO_SECRET_KEY . ':');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Accept: application/json"
]);

// Execute the cURL request
$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'cURL Error: ' . $curlError]);
    exit;
}

// Decode the response
$response = json_decode($result, true);

// Check if the Payment Link was created successfully
if ($httpCode === 200 || $httpCode === 201) {
    if (isset($response['data']['attributes']['checkout_url'])) {
        $checkoutUrl = $response['data']['attributes']['checkout_url'];
        $paymentLinkId = $response['data']['id'] ?? null;
        
        // Save payment record to database if order_db_id is provided
        if ($orderDbId) {
            try {
                require_once __DIR__ . '/../php/database.php';
                $database = new Database();
                $db = $database->getConnection();
                
                // Check if payments table exists
                $checkTable = $db->query("SHOW TABLES LIKE 'payments'");
                if ($checkTable && $checkTable->rowCount() > 0) {
                    $query = "INSERT INTO payments (order_id, paymongo_link_id, amount, status, metadata, created_at) 
                              VALUES (:order_id, :link_id, :amount, 'Pending', :metadata, NOW())
                              ON DUPLICATE KEY UPDATE 
                              paymongo_link_id = VALUES(paymongo_link_id),
                              metadata = VALUES(metadata),
                              updated_at = NOW()";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(':order_id', $orderDbId);
                    $stmt->bindParam(':link_id', $paymentLinkId);
                    $stmt->bindParam(':amount', $amount);
                    $metadata = json_encode([
                        'order_id' => $orderId,
                        'customer_name' => $customerName,
                        'description' => $description,
                        'payment_link' => $response['data']
                    ]);
                    $stmt->bindParam(':metadata', $metadata);
                    $stmt->execute();
                }
            } catch (Exception $e) {
                // Log error but continue with payment redirect
                error_log('Error saving payment record: ' . $e->getMessage());
            }
        }
        
        // Return JSON response for AJAX calls, or redirect for form submissions
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'true') {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'checkout_url' => $checkoutUrl,
                'payment_link_id' => $paymentLinkId,
                'order_id' => $orderId
            ]);
        } else {
            // Redirect to the checkout URL for payment
            header("Location: " . $checkoutUrl);
            exit();
        }
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Invalid response from PayMongo', 'response' => $response]);
    }
} else {
    $errorMsg = isset($response['errors'][0]['detail']) ? $response['errors'][0]['detail'] : 'Unknown error';
    http_response_code($httpCode);
    echo json_encode(['success' => false, 'message' => 'Failed to create payment link: ' . $errorMsg, 'response' => $response]);
}
