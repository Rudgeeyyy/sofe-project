README — Local XAMPP Setup & Database Import (port-aware)

Purpose
- Quick checklist and commands to verify XAMPP (Apache on ports 8080/8081, MySQL on 3306) and import the `jessiecane` SQL dump into the project.

Assumptions
- You're on Windows and using XAMPP.
- Apache serves your project (placed under `htdocs`) on ports 8080 or 8081.
- MySQL is the bundled XAMPP server listening on port 3306.
- Project folder is: `C:\xampp\htdocs\<your-project-folder>` or equivalent.
- SQL dump location (example): `C:\Users\rudge\Downloads\project (5)\project\jessiecane.sql`.
- DB credentials used in project files: user `pma`, password `Akolangnamanto123`, database `jessiecane`.

1) Start XAMPP services
- Recommended: open XAMPP Control Panel → Start `Apache` and `MySQL`.
- Optional (cmd.exe) if services installed:

  sc start Apache2.4
  sc start mysql

2) Confirm Apache & MySQL processes and ports (cmd.exe)
- Check processes:

  tasklist | findstr /I httpd
  tasklist | findstr /I mysqld

- Confirm ports listening (8080, 8081 for Apache; 3306 for MySQL):

  netstat -ano | findstr :8080
  netstat -ano | findstr :8081
  netstat -ano | findstr :3306

If a port is missing, Apache/MySQL may be stopped or bound to another app.

3) Open phpMyAdmin and project test page (browser)
- phpMyAdmin (port-aware):

  http://localhost:8080/phpmyadmin
  http://localhost:8081/phpmyadmin

- Project test file (adjust project folder name):

  http://localhost:8080/<your-project-folder>/php/test-connection.php
  http://localhost:8081/<your-project-folder>/php/test-connection.php

4) Verify `jessiecane` DB exists (MySQL CLI)
- If `mysql` is on PATH:

  mysql -u pma -p -e "SHOW DATABASES LIKE 'jessiecane';"

  (Enter password: `Akolangnamanto123`)

- Or use the XAMPP mysql client:

  "C:\xampp\mysql\bin\mysql.exe" -u pma -p -e "SHOW DATABASES LIKE 'jessiecane';"

Expected: a row showing `jessiecane`.

5) Import `jessiecane.sql` (if DB/tables missing)
- Create DB first (if needed) in phpMyAdmin or via CLI:

  "C:\xampp\mysql\bin\mysql.exe" -u pma -p -e "CREATE DATABASE IF NOT EXISTS jessiecane CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"

- Import using CLI (fast and reliable):

  "C:\xampp\mysql\bin\mysql.exe" -u pma -p jessiecane < "C:\Users\rudge\Downloads\project (5)\project\jessiecane.sql"

- Or use phpMyAdmin: select `jessiecane` → Import → choose file → Go.

6) Test application DB connection
- Ensure your project folder is in `htdocs` (or served by your virtual host).
- Open the `test-connection.php` script in browser (see step 3).
- Expected: green checks for DB connection, table existence and PHP extensions.

7) Edit credentials if your local MySQL differs
- Files with DB credentials in this repo (update as needed):
  - `php\database.php`
  - `public\db_connect.php`
  - `api\config\database.php`

- Example credentials used by the project:
  - host: `localhost`
  - db: `jessiecane`
  - user: `pma`
  - pass: `Akolangnamanto123`

8) Useful logs (if something fails)
- Apache error log: `C:\xampp\apache\logs\error.log`
- MySQL error log: `C:\xampp\mysql\data\mysql_error.log` (or `mysqld.log`)

View last 50 lines (PowerShell) from cmd.exe:

  powershell -command "Get-Content 'C:\\xampp\\apache\\logs\\error.log' -Tail 50"
  powershell -command "Get-Content 'C:\\xampp\\mysql\\data\\mysql_error.log' -Tail 50"

9) Common issues & fixes
- Port 8080/8081 not listening: change Apache `Listen` directive if necessary in `C:\xampp\apache\conf\httpd.conf`, then restart Apache.
- MySQL login denied: confirm username/password in the files above, or use `root` if your MySQL setup uses it (and update project files accordingly).
- Import foreign key errors: the provided dump disables FK checks; re-import to a fresh DB if tables partially exist.
- Missing PHP extensions: open `phpinfo()` page and enable `pdo_mysql`, `pdo`, `openssl`, `curl`, `mbstring`, `json` in `php.ini`, then restart Apache.

10) Optional next steps
- Centralize DB credentials into a single `config.php` or `.env` and update references across the repo (recommended). I can implement this for you.
- If you want, I can also scan the repo for any hardcoded `localhost:PORT` references and list them.

If something fails
- Copy the exact browser error or CLI output and paste it here.
- If a service won't start, paste the last 20 lines of the relevant log and I'll help troubleshoot.

---
Created for your local dev environment (Apache ports 8080/8081, MySQL 3306). Adjust file paths and project names where needed.
