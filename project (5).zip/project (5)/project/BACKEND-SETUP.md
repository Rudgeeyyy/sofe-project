# Backend Setup Guide - Apache ports 8080 and 8081

This guide will help you set up and connect the backend to your frontend application running on Apache (commonly on port `8080` or `8081`). If your Apache uses `8081`, replace `8080` with `8081` in the example URLs below.

## Prerequisites

1. **XAMPP** installed and running
2. **MySQL** service running in XAMPP (default port `3306`)
3. **Apache** configured to run on port `8080` or `8081` (update URLs accordingly)

## Step 1: Configure XAMPP Apache Port

1. Open XAMPP Control Panel
2. Click "Config" next to Apache
3. Select "httpd.conf"
4. Find the line: `Listen 80`
5. Change it to: `Listen 8080`
6. Save and restart Apache

Alternatively, you can also change in `httpd-ssl.conf` if you're using HTTPS.

## Step 2: Database Setup

1. Open phpMyAdmin at: `http://localhost:8080/phpmyadmin`
2. Create a new database named: `jessie_cane_db`
3. Import the SQL file: `database-setup.sql`
   - Click on `jessie_cane_db` database
   - Go to "Import" tab
   - Choose file `database-setup.sql`
   - Click "Go"

Alternatively, execute the SQL commands directly in the SQL tab.

## Step 3: Verify PHP API Structure

Make sure your project structure looks like this:

```
project/
├── php/
│   ├── login.php
│   ├── register.php
│   ├── logout.php
│   ├── get-all.php (products)
│   ├── get.php (products)
│   ├── create.php (products)
│   ├── update.php (products)
│   ├── delete.php (products)
│   ├── create-order.php
│   ├── get-orders.php
│   ├── get-order.php
│   ├── update-status.php (orders)
│   ├── profile.php
│   ├── inquiries.php
│   ├── xendit-create.php
│   ├── google-auth.php
│   ├── database.php
│   ├── response.php
│   └── auth-helpers.php
├── assets/
│   └── js/
│       └── api-helper.js
└── public/
    └── ...
```

## Step 4: API Endpoints

All API endpoints are in the `php/` folder and accessible at: `http://localhost:8080/project/php/`

### Authentication
- `POST /php/login.php` - User login (accepts `username` or `email` and `password`)
- `POST /php/register.php` - User registration
- `POST /php/logout.php` - User logout
- `GET /php/google-auth.php` - Get Google OAuth URL

### Products
- `GET /php/get-all.php` - Get all products
- `GET /php/get.php?id={id}` - Get single product
- `POST /php/create.php` - Create product (admin only)
- `PUT /php/update.php` - Update product (admin only)
- `DELETE /php/delete.php?id={id}` - Delete product (admin only)

### Orders
- `POST /php/create-order.php` - Create new order
- `GET /php/get-orders.php` - Get all orders (with optional filters)
- `GET /php/get-order.php?id={id}` - Get single order
- `POST /php/update-status.php` - Update order status (admin/cashier)

### Payments
- `POST /php/xendit-create.php` - Create GCash payment link

### Users
- `GET /php/profile.php?user_id={id}` - Get user profile
- `PUT /php/update.php` - Update user profile
- `POST /php/inquiries.php` - Submit event inquiry
- `GET /php/inquiries.php` - Get all inquiries (admin only)

## Step 5: Test the Backend

### Test Login API

Open browser console or use this JavaScript:

```javascript
fetch("http://localhost:8080/project/php/login.php", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    username: "admin",
    password: "admin123"
  })
})
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error:", error));
```

### Test Products API

```javascript
fetch("http://localhost:8080/project/php/get-all.php", {
  method: "GET",
  headers: { "Content-Type": "application/json" }
})
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error:", error));
```

## Step 6: Frontend Integration

The frontend JavaScript files have been updated to use the backend APIs. The `api-helper.js` file provides wrapper functions:

```javascript
// Login
const result = await AuthAPI.login('username', 'password');

// Get products
const products = await ProductsAPI.getAll();

// Create order
const order = await OrdersAPI.create(orderData);
```

## Default Credentials

After importing the database, you can login with:
- **Username/Email:** admin or admin@gmail.com
- **Password:** admin123
- **Role:** admin

## API Request Format

All POST requests should follow this pattern:

```javascript
fetch("http://localhost:8080/project/php/{endpoint}.php", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    // Your data here
  })
})
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error:", error));
```

## Troubleshooting

### CORS Errors
- Make sure all PHP files have CORS headers
- Check browser console for specific error messages
- Verify Apache mod_headers is enabled

### Database Connection Error
- Verify MySQL is running in XAMPP
- Check `php/database.php` credentials
- Ensure database `jessie_cane_db` exists

### 404 Errors
- Verify Apache is running on port 8080
- Check file paths are correct
- Ensure PHP files are in the `php/` folder

### API Not Responding
- Check Apache error log: `xampp/apache/logs/error.log`
- Verify PHP is enabled in Apache
- Test with direct URL: `http://localhost:8080/project/php/login.php`

## Notes

- All API endpoints use port `8080` (or `8081` if your Apache is configured that way)
- Login accepts both `username` and `email` fields
- All responses are in JSON format
- The frontend has localStorage fallback for offline/development use
