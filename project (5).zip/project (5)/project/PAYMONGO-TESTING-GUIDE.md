# PayMongo Integration Testing Guide

This guide will help you test and verify that the PayMongo payment integration is working correctly for both **Cashier Manual Orders** and **Customer Online Orders**.

## Prerequisites

1. ✅ PayMongo API keys are configured in `php/paymongo-create.php`
2. ✅ Webhook URL is set up in PayMongo Dashboard
3. ✅ Database connection is working
4. ✅ Apache/XAMPP server is running

---

## 🧪 Testing Methods

### Method 1: Test Cashier Manual Order with PayMongo

#### Step 1: Access Cashier Manual Order Page
1. Open your browser and navigate to:
   ```
   http://localhost:8080/project (5)/project/public/cashier_fairview/manual-order.php
   ```
   OR
   ```
   http://localhost:8080/project (5)/project/public/cashier_sjdm/manual-order.php
   ```

2. Log in as a cashier if prompted

#### Step 2: Create a Test Order
1. **Add items to cart:**
   - Click on any drink item
   - Select size (Regular/Tall)
   - Set quantity
   - Click "Add to Cart"

2. **Click "Place Order" button**

3. **Fill in customer details:**
   - Customer Name: `Test Customer`
   - Phone Number: `09123456789` (optional)
   - Branch: Should be auto-filled

4. **Select Payment Method:**
   - ✅ **Click "PayMongo (GCash/PayMaya/Card)" button**
   - The cash payment fields should hide
   - Payment method should show as selected

5. **Click "Confirm Order"**

#### Step 3: Verify Payment Redirect
1. **Expected behavior:**
   - Order should be created in database
   - You should be redirected to PayMongo checkout page
   - URL should look like: `https://pay.paymongo.com/...`

2. **On PayMongo checkout page:**
   - You should see payment options: GCash, PayMaya, Grab Pay, Card
   - Order amount should be displayed correctly

#### Step 4: Test Payment (Use Test Mode)
**⚠️ IMPORTANT: If using LIVE keys, this will charge REAL money!**

For testing, you can:
- Use PayMongo test mode (if configured)
- Use test card: `4242 4242 4242 4242` (any future expiry, any CVC)
- Or use real payment method for actual test

#### Step 5: Verify Order Status
After payment:
1. Check if redirected to: `thank-you.php?order=ORD-XXX`
2. Check database:
   ```sql
   SELECT * FROM orders WHERE order_id = 'ORD-XXX' ORDER BY id DESC LIMIT 1;
   ```
   - `payment_status` should be `Paid` (after webhook processes)
   - `payment_method` should be `paymongo`
   - `order_type` should be `Digital`

---

### Method 2: Test Customer Online Order

#### Step 1: Access Customer Menu
1. Navigate to:
   ```
   http://localhost:8080/project (5)/project/public/customer/drinks.php
   ```

#### Step 2: Place Order
1. **Add items to cart**
2. **Click "Checkout" or cart icon**
3. **Fill in order details:**
   - Customer name
   - Email
   - Phone
   - Select branch

4. **Click "Place Order"**

#### Step 3: Verify Payment Flow
1. **Expected:**
   - Popup should say: "You will be redirected to complete your payment via PayMongo..."
   - Click "Proceed"
   - Order created in database
   - Redirected to PayMongo checkout

2. **Complete payment** (same as Step 4 above)

3. **Verify redirect:**
   - Should redirect to `thank-you.php?order=ORD-XXX`
   - Order number should be displayed

---

## 🔍 Verification Checklist

### ✅ Frontend Checks

- [ ] Payment method buttons appear in cashier checkout modal
- [ ] Cash/PayMongo selection works (fields show/hide correctly)
- [ ] Order creation succeeds
- [ ] Redirect to PayMongo checkout works
- [ ] PayMongo checkout page loads with correct amount

### ✅ Backend Checks

**Check Browser Console:**
1. Open Developer Tools (F12)
2. Go to Console tab
3. Look for:
   - ✅ `Order saved to backend:` message
   - ✅ `Payment creation error:` (should NOT appear)
   - ✅ Any API errors

**Check Network Tab:**
1. Go to Network tab in Developer Tools
2. Look for requests to:
   - `/php/create-order.php` - Should return `success: true`
   - `/php/paymongo-create.php` - Should return `checkout_url`
3. Check response status codes (should be 200)

### ✅ Database Checks

**Check Orders Table:**
```sql
SELECT 
    id,
    order_id,
    customer_name,
    total,
    payment_method,
    payment_status,
    order_type,
    order_status,
    created_at
FROM orders 
ORDER BY id DESC 
LIMIT 5;
```

**Expected values:**
- `payment_method` = `paymongo` (for PayMongo orders)
- `order_type` = `Digital` (for PayMongo orders)
- `payment_status` = `Pending` (initially, then `Paid` after webhook)

**Check Payments Table (if exists):**
```sql
SELECT * FROM payments ORDER BY id DESC LIMIT 5;
```

### ✅ Webhook Checks

**Check PayMongo Dashboard:**
1. Go to [PayMongo Dashboard](https://dashboard.paymongo.com)
2. Navigate to **Webhooks** → **Logs**
3. Look for recent webhook events:
   - `payment_intent.succeeded`
   - `payment.paid`
4. Check if webhook was delivered successfully

**Check Server Logs:**
- Check PHP error logs for webhook processing
- Look for: `PayMongo Webhook: payment.paid` messages

**Verify Webhook Updates:**
After payment, check database again:
```sql
SELECT payment_status, order_status 
FROM orders 
WHERE order_id = 'ORD-XXX';
```
- Should be `Paid` and `Approved` after webhook processes

---

## 🐛 Troubleshooting

### Issue: Payment method buttons don't appear
**Solution:**
- Check browser console for JavaScript errors
- Verify `manual-order.php` has the payment method HTML
- Clear browser cache and reload

### Issue: Redirect to PayMongo doesn't work
**Possible causes:**
1. **API Error:**
   - Check browser console for error messages
   - Verify `PaymentsAPI.createPayMongo` is available
   - Check if `api-helper.js` is loaded

2. **Backend Error:**
   - Check `php/paymongo-create.php` for errors
   - Verify PayMongo API keys are correct
   - Check database connection

3. **Network Error:**
   - Verify server is running
   - Check CORS headers
   - Verify API endpoint is accessible

### Issue: Order created but payment link fails
**Check:**
1. Browser console for error messages
2. Network tab for failed API calls
3. PHP error logs
4. Verify PayMongo API keys are valid

### Issue: Webhook not updating order status
**Check:**
1. PayMongo Dashboard → Webhooks → Logs
2. Verify webhook URL is correct and accessible
3. Check `php/paymongo-webhook.php` for errors
4. Verify webhook secret is correct
5. Check if webhook events are enabled in PayMongo Dashboard

### Issue: Payment succeeds but order status stays "Pending"
**Solution:**
- Webhook might not be processing correctly
- Check webhook logs in PayMongo Dashboard
- Verify webhook URL is publicly accessible (use ngrok for local testing)
- Check `php/paymongo-webhook.php` error logs

---

## 🧪 Quick Test Script

You can also test the API directly using curl or Postman:

### Test PayMongo Payment Creation
```bash
curl -X POST http://localhost:8080/project (5)/project/php/paymongo-create.php \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "amount": 100.00
  }'
```

**Expected response:**
```json
{
  "success": true,
  "message": "PayMongo payment created successfully",
  "data": {
    "payment_intent_id": "pi_...",
    "checkout_url": "https://pay.paymongo.com/...",
    "public_key": "pk_live_...",
    "amount": 100,
    "order_id": "ORD-001"
  }
}
```

---

## 📝 Testing Checklist Summary

### Cashier Flow
- [ ] Can select PayMongo payment method
- [ ] Cash fields hide when PayMongo selected
- [ ] Order creates successfully
- [ ] Redirects to PayMongo checkout
- [ ] Payment completes
- [ ] Order status updates to "Paid"

### Customer Flow
- [ ] Order creates successfully
- [ ] Redirects to PayMongo checkout
- [ ] Payment completes
- [ ] Redirects to thank-you page
- [ ] Order status updates to "Paid"

### Webhook Flow
- [ ] Webhook receives payment events
- [ ] Order status updates automatically
- [ ] Payment status updates to "Paid"

---

## 🔗 Useful Links

- **PayMongo Dashboard:** https://dashboard.paymongo.com
- **PayMongo API Docs:** https://developers.paymongo.com/docs
- **Test Cards:** https://developers.paymongo.com/docs/testing

---

## 📞 Need Help?

If you encounter issues:
1. Check browser console for errors
2. Check PHP error logs
3. Verify PayMongo Dashboard webhook logs
4. Check database for order records
5. Verify API keys are correct

---

**Last Updated:** $(date)
**Integration Status:** ✅ Connected

