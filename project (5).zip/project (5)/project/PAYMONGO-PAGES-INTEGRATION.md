# Connecting PayMongo Payment Method Pages to Main System

This guide explains how to connect the standalone payment pages in `paymongo-payment-method/` folder to your main system.

## 📁 Current Pages

1. **`paymongo-payment-method/index.php`** - Standalone payment form
2. **`paymongo-payment-method/create_payment.php`** - Payment link creation (already integrated)
3. **`paymongo-payment-method/callback.php`** - Payment callback handler

---

## 🔗 Integration Options

### Option 1: Use as Standalone Payment Page

You can use `index.php` as a standalone payment page that customers can access directly.

**Access URL:**
```
http://localhost:8080/project (5)/project/paymongo-payment-method/index.php
```

**How it works:**
- Customer enters amount
- Submits form
- Redirects to PayMongo checkout
- After payment, customer needs to be redirected back

**To connect it to your order system, update `index.php`:**

```php
<!-- Add order ID field -->
<input type="hidden" name="order_id" value="<?php echo $_GET['order_id'] ?? ''; ?>">
<input type="hidden" name="order_db_id" value="<?php echo $_GET['order_db_id'] ?? ''; ?>">
```

---

### Option 2: Link from Order Confirmation Pages

Add a link to the payment page from your order confirmation or thank-you page.

**In `public/customer/thank-you.php` or order confirmation pages:**

```php
<?php
$orderId = $_GET['order'] ?? '';
$orderDbId = $_GET['order_db_id'] ?? '';
$total = $_GET['total'] ?? '';
?>

<!-- Add payment button if payment is pending -->
<?php if ($paymentStatus === 'Pending'): ?>
    <div style="margin-top: 20px;">
        <a href="../../paymongo-payment-method/index.php?order_id=<?php echo urlencode($orderId); ?>&order_db_id=<?php echo urlencode($orderDbId); ?>&total=<?php echo urlencode($total); ?>" 
           class="btn btn-primary">
            <i class="fa-solid fa-credit-card"></i> Complete Payment
        </a>
    </div>
<?php endif; ?>
```

---

### Option 3: Integrate with Order Flow

Update `index.php` to accept order information and pre-fill the form.

**Updated `paymongo-payment-method/index.php`:**

```php
<?php
// Get order information from URL parameters
$orderId = $_GET['order_id'] ?? '';
$orderDbId = $_GET['order_db_id'] ?? '';
$total = isset($_GET['total']) ? floatval($_GET['total']) : 0;
$customerName = $_GET['customer_name'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... existing head content ... -->
</head>
<body>
    <div class="container">
        <h2>Complete Your Payment</h2>
        <?php if ($orderId): ?>
            <p style="margin-bottom: 15px; color: #666;">
                Order: <strong><?php echo htmlspecialchars($orderId); ?></strong>
            </p>
        <?php endif; ?>
        <form action="create_payment.php" method="POST">
            <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($orderId); ?>">
            <input type="hidden" name="order_db_id" value="<?php echo htmlspecialchars($orderDbId); ?>">
            <input type="hidden" name="customer_name" value="<?php echo htmlspecialchars($customerName); ?>">
            
            <label for="amount">Amount (PHP):</label>
            <input type="number" name="amount" value="<?php echo $total > 0 ? $total : ''; ?>" 
                   min="1" step="0.01" required><br>
            
            <label for="description" style="margin-top: 15px;">Description:</label>
            <input type="text" name="description" 
                   value="<?php echo $orderId ? 'Order ' . htmlspecialchars($orderId) : 'Payment'; ?>" 
                   placeholder="Payment description"><br>
            
            <button type="submit">Pay Now</button>
        </form>
    </div>
</body>
</html>
```

---

### Option 4: Update create_payment.php to Save Order Info

Update `create_payment.php` to save payment information linked to orders.

**Enhanced `paymongo-payment-method/create_payment.php`:**

```php
<?php
// ... existing code ...

// Get order information if provided
$orderId = $_POST['order_id'] ?? null;
$orderDbId = $_POST['order_db_id'] ?? null;
$customerName = $_POST['customer_name'] ?? '';

// ... existing payment link creation code ...

// After creating payment link successfully, save to database
if ($httpCode === 200 || $httpCode === 201) {
    if (isset($response['data']['attributes']['checkout_url'])) {
        $checkoutUrl = $response['data']['attributes']['checkout_url'];
        $paymentLinkId = $response['data']['id'] ?? null;
        
        // Save payment record if order_db_id is provided
        if ($orderDbId) {
            try {
                require_once __DIR__ . '/../php/database.php';
                $database = new Database();
                $db = $database->getConnection();
                
                // Check if payments table exists
                $checkTable = $db->query("SHOW TABLES LIKE 'payments'");
                if ($checkTable && $checkTable->rowCount() > 0) {
                    $query = "INSERT INTO payments (order_id, paymongo_link_id, amount, status, metadata, created_at) 
                              VALUES (:order_id, :link_id, :amount, 'Pending', :metadata, NOW())
                              ON DUPLICATE KEY UPDATE 
                              paymongo_link_id = VALUES(paymongo_link_id),
                              metadata = VALUES(metadata)";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(':order_id', $orderDbId);
                    $stmt->bindParam(':link_id', $paymentLinkId);
                    $stmt->bindParam(':amount', $amount);
                    $metadata = json_encode([
                        'order_id' => $orderId,
                        'customer_name' => $customerName,
                        'payment_link' => $response['data']
                    ]);
                    $stmt->bindParam(':metadata', $metadata);
                    $stmt->execute();
                }
            } catch (Exception $e) {
                error_log('Error saving payment: ' . $e->getMessage());
            }
        }
        
        // Redirect to checkout
        header("Location: " . $checkoutUrl);
        exit();
    }
}
```

---

### Option 5: Add Payment Link to Cashier/Customer Dashboards

Add a "Pay Now" button in order lists for pending payments.

**In cashier or customer order lists:**

```javascript
// Add payment button for pending PayMongo orders
function renderOrderWithPayment(order) {
    let html = `
        <div class="order-item">
            <h4>Order: ${order.order_id}</h4>
            <p>Total: ₱${order.total}</p>
            <p>Status: ${order.payment_status}</p>
    `;
    
    // Add payment button if payment is pending and method is PayMongo
    if (order.payment_status === 'Pending' && order.payment_method === 'paymongo') {
        html += `
            <a href="../../paymongo-payment-method/index.php?order_id=${order.order_id}&order_db_id=${order.order_db_id}&total=${order.total}&customer_name=${encodeURIComponent(order.customer_name)}" 
               class="btn btn-primary" target="_blank">
                <i class="fa-solid fa-credit-card"></i> Complete Payment
            </a>
        `;
    }
    
    html += `</div>`;
    return html;
}
```

---

### Option 6: Create Success/Cancel Redirect Pages

Create redirect pages that handle payment completion.

**Create `paymongo-payment-method/success.php`:**

```php
<?php
$orderId = $_GET['order_id'] ?? '';
$paymentId = $_GET['payment_id'] ?? '';

// Redirect to main thank-you page
if ($orderId) {
    header("Location: ../../public/customer/thank-you.php?order=" . urlencode($orderId));
} else {
    header("Location: ../../public/customer/drinks.php?payment=success");
}
exit();
?>
```

**Create `paymongo-payment-method/cancel.php`:**

```php
<?php
$orderId = $_GET['order_id'] ?? '';

// Redirect back with cancel message
if ($orderId) {
    header("Location: ../../public/customer/drinks.php?payment=cancelled&order=" . urlencode($orderId));
} else {
    header("Location: ../../public/customer/drinks.php?payment=cancelled");
}
exit();
?>
```

**Update PayMongo success/cancel URLs in `create_payment.php`:**

```php
// Build success and cancel URLs
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/project (5)/project';

$successUrl = $baseUrl . '/paymongo-payment-method/success.php?order_id=' . urlencode($orderId);
$cancelUrl = $baseUrl . '/paymongo-payment-method/cancel.php?order_id=' . urlencode($orderId);

// Add to payment link metadata
$data = [
    "data" => [
        "attributes" => [
            "amount" => $amountInCents,
            "currency" => "PHP",
            "description" => $description,
            "remarks" => $remarks,
            "redirect" => [
                "success" => $successUrl,
                "failed" => $cancelUrl
            ]
        ]
    ]
];
```

---

## 🔄 Complete Integration Flow

Here's how the complete flow would work:

1. **Customer places order** → Order created with `payment_status = 'Pending'`
2. **Customer redirected** → To `paymongo-payment-method/index.php?order_id=XXX&total=YYY`
3. **Form pre-filled** → Amount and order info already filled
4. **Customer clicks "Pay Now"** → Submits to `create_payment.php`
5. **Payment link created** → Redirects to PayMongo checkout
6. **Customer pays** → On PayMongo's page
7. **Payment success** → Redirects to `success.php` → Then to `thank-you.php`
8. **Webhook updates** → `php/paymongo-webhook.php` updates order status to "Paid"

---

## 📝 Quick Integration Checklist

- [ ] Update `index.php` to accept order parameters
- [ ] Update `create_payment.php` to save payment records
- [ ] Create `success.php` redirect page
- [ ] Create `cancel.php` redirect page
- [ ] Add payment links in order lists
- [ ] Test the complete flow
- [ ] Update webhook to handle payments from these pages

---

## 🧪 Testing

1. **Test standalone page:**
   ```
   http://localhost:8080/project (5)/project/paymongo-payment-method/index.php?order_id=ORD-001&total=100
   ```

2. **Test with order:**
   - Create an order
   - Get order ID
   - Access payment page with order info
   - Complete payment
   - Verify order status updates

---

## 💡 Recommended Approach

**For your system, I recommend:**

1. **Keep the main flow** (already working) - Customer orders → Auto-redirects to PayMongo
2. **Use standalone pages for:**
   - Manual payment links (cashier can generate)
   - Re-payment for failed orders
   - Direct payment links (share via email/SMS)
   - Testing and debugging

This gives you flexibility while keeping the main automated flow intact!

