<?php
// Include parent db_connect
include '../db_connect.php';
?>

